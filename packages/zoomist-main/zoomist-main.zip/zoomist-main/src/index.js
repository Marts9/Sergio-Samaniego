import './scss/index.scss'
import Zoomist from './js/zoomist'

export default Zoomist